import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import "./style.css";
import Slotty from "./Slotty.png";

function LoginPage() {
  const [isOpen, setIsOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (username === 'Slotty' && password === 'Slotty@2025') {
      navigate('/admin');
      alert('🎉 Welcome to the Admin Page!');
    } else if (username && password) {
      alert('✅ Login Successful!');
      navigate('/book');
    } else {
      alert('❌ Invalid username or password. Try again!');
    }
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
                <div className="container px-4">
                    <Link className="navbar-brand" to="/">
                        <img src={Slotty} className='logo' alt='logo'/>
                    </Link>
                    <button 
                        className="navbar-toggler bg-secondary" 
                        type="button" 
                        onClick={() => setIsOpen(!isOpen)}
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse box navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
                        <ul className='navbar-nav ms-auto lit fs-100'>
                            <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
                            <li className="nav-item"><Link to="/book" className='nav-link link '><i class="bi bi-p-circle"></i> Book Slot</Link></li>
                            <li className="nav-item"><Link to="/Mybook" className='nav-link link '><i class="bi bi-clock-history"></i> My Booking</Link></li>
                            <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
                            <li className="nav-item"><Link to="/login" className='nav-link org '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>

      <div className='bot d-flex align-items-center justify-content-center' style={{ minHeight: '100vh', background: 'linear-gradient(135deg,rgb(255, 255, 255),rgb(255, 255, 255))' }}>
        <div className="container p-5 bg-white rounded-4 shadow-lg" style={{ maxWidth: '450px' }}>
          <center>
            <h1 className="mb-4 text-info">Login to continue</h1>
            <input
              type="text"
              className="form-control mb-3 rounded"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              className="form-control mb-3 rounded"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button className="btn btn-success w-100 " onClick={handleLogin} style={{borderRadius:"3px"}}>Login</button><br /><br />

            <div className="forgotpass text-muted">
              <Link to="#" className="text-decoration-none">Forgot Password?</Link><span> | </span><Link to="#" className="text-decoration-none">Register</Link>
            </div>
            <br />
            <div className="separator"><hr /></div>

            <div className="loginmethods">
              <button type="button" className="btn btn-outline-danger w-100 mb-2 rounded-pill">
                <i className="bi bi-google"></i> Sign in with Google
              </button>
              <button type="button" className="btn btn-outline-dark w-100 mb-2 rounded-pill">
                <i className="bi bi-apple"></i> Sign in with Apple
              </button>
              <button type="button" className="btn btn-outline-primary w-100 rounded-pill">
                <i className="bi bi-facebook"></i> Sign in with Facebook
              </button>
            </div>
          </center>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;

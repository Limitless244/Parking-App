import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Slotty from "./Slotty.png"; 

export default function MyBooking() {
  const [isOpen, setIsOpen] = useState(false); 
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const storedBookings = JSON.parse(localStorage.getItem('bookings')) || [];
    setBookings(storedBookings);
  }, []);
  const handleCancelBooking = (index) => {
    const updatedBookings = bookings.filter((_, i) => i !== index);
    setBookings(updatedBookings);
    localStorage.setItem('bookings', JSON.stringify(updatedBookings));
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
        <div className="container px-4">
          <Link className="navbar-brand" to="/">
            <img src={Slotty} className='logo' alt='logo'/>
          </Link>
          <button 
            className="navbar-toggler bg-secondary" 
            type="button" 
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
            <ul className='navbar-nav ms-auto lit fs-100'>
              <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
              <li className="nav-item"><Link to="/book" className='nav-link link '><i className="bi bi-p-circle"></i> Book Slot</Link></li>
              <li className="nav-item"><Link to="/Mybook" className='nav-link org '><i className="bi bi-clock-history"></i> My Booking</Link></li>
              <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
              <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
            </ul>
          </div>
        </div>
      </nav>


      <div className="container mt-5 pt-5">
        <h1 className="text-center">My Bookings</h1>
        <hr />
        {bookings.length > 0 ? (
          <div className="row">
            {bookings.map((booking, index) => (
              <div key={index} className="col-md-6 col-lg-4 mb-3">
                <div className="card shadow-sm p-3">
                  <div className="card-body">
                    <h5 className="card-title text-primary">{booking.name}</h5>
                    <p className="mb-1"><strong>Vehicle:</strong> {booking.vehicle}</p>
                    <p className="mb-1"><strong>Slots:</strong> {booking.slots.join(', ')}</p>
                    <p className="text-danger"><strong>Slot is booked</strong></p>
                    <p className="mb-1"><strong>Date:</strong> {booking.date}</p>
                    <p className="mb-1"><strong>Time:</strong> {booking.time}</p>
                    <button className="btn btn-danger mt-2" onClick={() => handleCancelBooking(index)}>
                      Cancel Booking
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center">No bookings found.</p>
        )}
      </div>
      <footer className="bg-black text-white py-4 mt-5">
        <div className="container">
          <div className="row text-center text-md-start">
            <div className="col-md-4 mb-3">
              <h5 className="fw-bold">QUICK LINKS</h5>
              <ul className="list-unstyled">
                <li><Link to="/" className="text-decoration-none text-light">Home</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">How To Park</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">About</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">How It Works</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">Start Business</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">Privacy Policy</Link></li>
                <li><Link to="#" className="text-decoration-none text-light">Terms of Use</Link></li>
              </ul>
            </div>
            <div className="col-md-4 text-center mb-3">
              <h5 className="fw-bold">BECOME A PARTNER</h5>
              <p className="text-light">
                Convert your empty space into revenue-generating parking spaces with zero investment by partnering with InstaParking automated cashless systems.
              </p>
            </div>
            <div className="col-md-4 mb-3">
              <h5 className="fw-bold">CONTACT US</h5>
              <p><i className="bi bi-envelope"></i> <a href="/home" className="text-light">Slotty25@Slotty.in</a></p>
              <p><i className="bi bi-telephone"></i> 8008005072</p>
              <p><i className="bi bi-geo-alt"></i> Coimbatore</p>
            </div>
          </div>

          <hr className="bg-light mt-4" />
          <div className="text-center">
            <div className="d-flex justify-content-center gap-3 mb-3">
              <Link to="#" className="text-light fs-4"><i className="bi bi-facebook"></i></Link>
              <Link to="#" className="text-light fs-4"><i className="bi bi-twitter"></i></Link>
              <Link to="#" className="text-light fs-4"><i className="bi bi-linkedin"></i></Link>
              <Link to="#" className="text-light fs-4"><i className="bi bi-instagram"></i></Link>
            </div>
            <p className="text-light">© 2025 SlottyParking. All rights reserved.</p>
          </div>
        </div>
      </footer>  
    </div>
  );
}

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoginPage from './LoginPage';
import AdminPage from './AdminPage';
import TableBooking from './Slotbooking';
import Bookslot from './bookslot';
import Home from './Home';
import About from './About';
import MyBooking from './Mybooking';
function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/book" element={<Bookslot />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/book/:restaurantId" element={<TableBooking />} />
          <Route path='/Mybook' element={<MyBooking />}/>
        </Routes>
      </div>
    </Router>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './style.css';
import Slotty from "./Slotty.png";

export default function SlotBooking() {
  const [isOpen, setIsOpen] = useState(false);
  const { restaurantId } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const [selectedTables, setSelectedTables] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookedSlots, setBookedSlots] = useState([]);

  useEffect(() => {
    const storedBookings = JSON.parse(localStorage.getItem('bookings')) || [];
    const bookedSlotsList = storedBookings.flatMap(booking => booking.slots);
    setBookedSlots(bookedSlotsList);

    const fetchedRestaurant = {
      description: 'Secure Parking with Easy Booking',
      tables: [
        { number: '1', status: bookedSlotsList.includes('1') ? 'Booked' : 'Available' },
        { number: '2', status: bookedSlotsList.includes('2') ? 'Booked' : 'Available' },
        { number: '3', status: bookedSlotsList.includes('3') ? 'Booked' : 'Available' },
        { number: '4', status: bookedSlotsList.includes('4') ? 'Booked' : 'Available' },
        { number: '5', status: bookedSlotsList.includes('5') ? 'Booked' : 'Available' },
        { number: '6', status: bookedSlotsList.includes('6') ? 'Booked' : 'Available' }
      ]
    };
    setRestaurant(fetchedRestaurant);
  }, [restaurantId]);

  const handleTableSelection = (tableNumber) => {
    if (bookedSlots.includes(tableNumber)) {
      alert(`Slot ${tableNumber} is already booked!`);
      return;
    }
    setSelectedTables((prevSelected) =>
      prevSelected.includes(tableNumber)
        ? prevSelected.filter((num) => num !== tableNumber)
        : [...prevSelected, tableNumber]
    );
  };

  const handleBooking = (e) => {
    e.preventDefault();

    if (selectedTables.length === 0) {
      alert('Please select at least one parking slot.');
      return;
    }

    if (!customerName || !customerEmail || !customerPhone || !vehicleNumber || !bookingDate || !bookingTime) {
      alert('Please fill out all details.');
      return;
    }

    const newBooking = {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      vehicle: vehicleNumber,
      date: bookingDate,
      time: bookingTime,
      slots: selectedTables,
    };

    const existingBookings = JSON.parse(localStorage.getItem('bookings')) || [];
    localStorage.setItem('bookings', JSON.stringify([...existingBookings, newBooking]));

    alert(`Booking confirmed for slots ${selectedTables.join(', ')} on ${bookingDate} at ${bookingTime}!`);

    setSelectedTables([]);
    setCustomerName('');
    setCustomerEmail('');
    setCustomerPhone('');
    setVehicleNumber('');
    setBookingDate('');
    setBookingTime('');

    setBookedSlots([...bookedSlots, ...selectedTables]);
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
        <div className="container px-4">
          <Link className="navbar-brand" to="/">
            <img src={Slotty} className='logo' alt='logo'/>
          </Link>
          <button 
            className="navbar-toggler bg-secondary" 
            type="button" 
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
            <ul className='navbar-nav ms-auto lit fs-100'>
              <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
              <li className="nav-item"><Link to="/book" className='nav-link link org '><i className="bi bi-p-circle"></i> Book Slot</Link></li>
              <li className="nav-item"><Link to="/Mybook" className='nav-link link '><i className="bi bi-clock-history"></i> My Booking</Link></li>
              <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
              <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
            </ul>
          </div>
        </div>
      </nav>

      <div className="container mt-5 rent bot">
        {restaurant ? (
          <>
            <h1>Book a Parking Slot</h1><hr/>
            <h4>{restaurant.description}</h4><br/>
            <h4>Available Slots:</h4>
            <div className="row">
              {restaurant.tables.map((table) => (
                <div className="col-md-4" key={table.number}>
                  <button
                    className={`btn ${selectedTables.includes(table.number) ? 'btn-secondary' : (bookedSlots.includes(table.number) ? 'btn-danger' : 'btn-success')} w-100 table`}
                    onClick={() => handleTableSelection(table.number)}
                    disabled={bookedSlots.includes(table.number)}
                  >
                    Slot {table.number} - {bookedSlots.includes(table.number) ? 'Booked' : 'Available'}
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-4">
              <center>
                <input type="text" className="form-control mb-2" placeholder="Your Name" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
                <input type="email" className="form-control mb-2" placeholder="Your Email" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} />
                <input type="tel" className="form-control mb-2" placeholder="Your Phone Number" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} />
                <input type="text" className="form-control mb-2" placeholder="Vehicle Number" value={vehicleNumber} onChange={(e) => setVehicleNumber(e.target.value)} />
                <input type="date" className="form-control mb-2" value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} />
                <input type="time" className="form-control mb-2" value={bookingTime} onChange={(e) => setBookingTime(e.target.value)} />
                <button className="btn btn-primary w-30 p-2" onClick={handleBooking}>Confirm Booking</button>
              </center>
            </div>
          </>
        ) : (
          <p>Loading parking details...</p>
        )}
      </div>
    </div>
  );
}

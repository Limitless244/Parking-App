import React, { useState } from 'react';
import "./style.css";
import { Link } from 'react-router-dom';
import Slotty from "./Slotty.png";
function AdminPage() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
                <div className="container px-4">
                    <Link className="navbar-brand" to="/">
                        <img src={Slotty} className='logo' alt='logo'/>
                    </Link>
                    <button 
                        className="navbar-toggler bg-secondary" 
                        type="button" 
                        onClick={() => setIsOpen(!isOpen)}
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
                        <ul className='navbar-nav ms-auto lit fs-100'>
                            <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
                            <li className="nav-item"><Link to="/book" className='nav-link link '><i class="bi bi-p-circle"></i> Book Slot</Link></li>
                            <li className="nav-item"><Link to="/Mybook" className='nav-link link '><i class="bi bi-clock-history"></i> My Booking</Link></li>
                            <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
                            <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>
      <div  className="container mt-5 bot">
      <h1>Admin Dashboard</h1>
      <p>Manage your Parking</p>
      <button className="btn btn-warning p-2">Add New places</button>
      <Link to="/Mybook"><button className="btn btn-info p-2 admbtn">View All Bookings</button></Link>
      </div>
    </div>
  );
}

export default AdminPage;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './style.css';
import Slotty from "./Slotty.png"; 
export default function Bookslot() {
  const [isOpen, setIsOpen] = useState(false);
  const [bookings] = useState([
    { id: '1', name: 'Mountain View Parking', description: 'Mountain View, California With Real Reviews and 24/7 Services', img: 'https://i.ibb.co/3YTcpJMJ/image1.jpg'},
    { id: '2', name: 'ParkXpert', description: 'ParkXpert Mosman Park, Perth Western Australia, Australia', img: 'https://i.ibb.co/v61f0RJj/image2.jpg'},
    { id: '3', name: 'Mile2Parking', description: 'It offers convenient and budget-friendly parking options with hourly', img: 'https://i.ibb.co/39vH72fQ/image3.webp'},
    { id: '4', name: 'A new cars and transportation', description: ' Premium valet and self-parking near Magnificent Mile.', img: 'https://i.ibb.co/0jCHZHMV/image4.jpg'},
    { id: '5', name: 'ParkingSOS', description: 'Instant parking reservations for hassle-free city driving.', img: 'https://i.ibb.co/XZdGjmHM/image5.jpg'},
    { id: '6', name: 'parkmium', description: 'Luxury parking with EV charging and VIP services and Hightech.', img: 'https://i.ibb.co/RT0BqHKL/image6.jpg'},
    { id: '7', name: 'DriveOnPark', description: 'Digital reservations and real-time parking updates.', img: 'https://i.ibb.co/fz7fHpgj/image7.jpg'},
    { id: '8', name: 'Parking Lot Management Inc', description: 'Expert parking solutions for businesses and residences.', img: 'https://i.ibb.co/3yqb4WfB/image8.jpg'},
    { id: '9', name: 'ParkMentor', description: 'AI-powered parking assistance and guidance and Security.', img: 'https://i.ibb.co/yn7QhsYC/image9.jpg'},
    { id: '10', name: 'U Parking Lot', description: ' Covered parking near casinos and entertainment.', img: 'https://i.ibb.co/zTqzTHzJ/image10.jpg'},
    { id: '11', name: 'Parking Lot Consultancy Pty Ltd', description: 'Parking design and management consulting.', img: 'https://i.ibb.co/QF518CM1/image11.jpg'},
    { id: '12', name: 'Parker Parking', description: ' Secure, long-term parking near transport hubs.', img: 'https://i.ibb.co/r27tJyRP/image12.jpg'},
    { id: '13', name: 'Parking Lot of the future', description: 'AI-powered robotic valet parking.', img: 'https://i.ibb.co/xqp9m7fd/image13.jpg'},
    { id: '14', name: 'LOTOPARADISE', description: 'Spacious parking near Disney World.', img: 'https://i.ibb.co/gLhcjxQM/image14.jpg'},
    { id: '15', name: 'Co Parking Lot', description: ' Convenient airport parking with free shuttles.', img: 'https://i.ibb.co/VYGrYKFt/image15.jpg'},
  ]);

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
                <div className="container px-4">
                    <Link className="navbar-brand" to="/">
                        <img src={Slotty} className='logo' alt='logo'/>
                    </Link>
                    <button 
                        className="navbar-toggler bg-secondary" 
                        type="button" 
                        onClick={() => setIsOpen(!isOpen)}
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse box navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
                        <ul className='navbar-nav ms-auto lit fs-100'>
                            <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
                            <li className="nav-item"><Link to="/book" className='nav-link org '><i class="bi bi-p-circle"></i> Book Slot</Link></li>
                            <li className="nav-item"><Link to="/Mybook" className='nav-link link '><i class="bi bi-clock-history"></i> My Booking</Link></li>
                            <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
                            <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>
      <div className="container mt-5 bot" style={{ marginTop: "80px" }}>
      <h1>Book <span className="tex">Your</span> Slot Too <span className="tex">Easy</span></h1><br/><hr/><br/>
      <center><h2>Select a Booking Location</h2></center><br/>
      <div className="row location">
        {
          bookings.map((booking) => (
            <div className="loca col-md-4" key={booking.id}>
              <div className='img-col'>
                <img src={booking.img} className="image img-fluid" alt={booking.name}/>
                <div className='para'>
                <center><h5>{booking.name}</h5>
                  <p>{booking.description}</p>
                  <Link to={`/book/${booking.id}`} className="btn btn-info">
                    Bookslot Here
                  </Link></center>
                </div>
              </div>
            </div>
          ))
        }
        </div>
      </div>
     <footer className="bg-black text-white py-4" style={{opacity:"0.8"}}>
           <div className="container">
             <div className="row">
               <div className="col-md-4">
                 <h5 className="fw-bold mb-3">QUICK LINKS</h5>
                 <ul className="list-unstyled">
                   <li><Link to="/" className="text-decoration-none text-light">Home</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">How To Park</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">About</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">How It Works</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">Start Business</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">Privacy Policy</Link></li>
                   <li><Link to="#" className="text-decoration-none text-light">Terms of Use</Link></li>
                 </ul>
               </div>
               <div className="col-md-4 text-center">
                 <h5 className="fw-bold mb-3">BECOME A PARTNER</h5>
                 <p className="text-light">
                   Convert your empty space into revenue-generating parking spaces with zero investment by partnering with InstaParking automated cashless systems.
                 </p>
               </div>
               <div className="col-md-4">
                 <h5 className="fw-bold mb-3">CONTACT US</h5>
                 <p><i className="bi bi-envelope"></i> <a href="/home" className="text-light">Slotty25@Slotty.in</a></p>
                 <p><i className="bi bi-telephone"></i> 8008005072</p>
                 <p><i className="bi bi-geo-alt"></i> Coimbatore</p>
               </div>
     
             </div>
     
             <hr className="bg-light mt-4" />
             <div className="text-center">
               <div className="d-flex justify-content-center gap-3 mb-3">
                 <Link to="#" className="text-light fs-4"><i className="bi bi-facebook"></i></Link>
                 <Link to="#" className="text-light fs-4"><i className="bi bi-twitter"></i></Link>
                 <Link to="#" className="text-light fs-4"><i className="bi bi-linkedin"></i></Link>
                 <Link to="#" className="text-light fs-4"><i className="bi bi-instagram"></i></Link>
               </div>
               <p className="text-light">© 2025 SlottyParking. All rights reserved.</p>
             </div>
           </div>
         </footer> 
      
    </div>
  );
}
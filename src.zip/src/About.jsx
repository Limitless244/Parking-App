import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./style.css";
import Slotty from "./Slotty.png";
export default function About() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className='bot'>
      <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
                <div className="container px-4">
                    <Link className="navbar-brand" to="/">
                        <img src={Slotty} className='logo' alt='logo'/>
                    </Link>
                    <button 
                        className="navbar-toggler bg-secondary" 
                        type="button" 
                        onClick={() => setIsOpen(!isOpen)}
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
                        <ul className='navbar-nav ms-auto lit fs-100'>
                            <li className="nav-item"><Link to="/" className='nav-link link '><i className="bi bi-house"></i> Home</Link></li>
                            <li className="nav-item"><Link to="/book" className='nav-link link '><i class="bi bi-p-circle"></i> Book Slot</Link></li>
                            <li className="nav-item"><Link to="/Mybook" className='nav-link link '><i class="bi bi-clock-history"></i> My Booking</Link></li>
                            <li className="nav-item"><Link to="/about" className='nav-link org '><i className="bi bi-file-person-fill"></i> About us</Link></li>
                            <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>
      <div className="container mt-5 con">
        <h1 className="text-center">About Us</h1>
        <p className="text-center">
          Welcome to <strong>Slotty</strong>, Slotty is an intuitive, user-friendly platform designed to help you book slots with ease. Our goal is to provide a seamless experience for managing bookings, saving you time, and offering secure scheduling options.
        </p>

        <h3>Why Choose Us?</h3>
        <ul className='par'>
          <li><strong>Quick & Easy Booking:</strong> Reserve your favorite slot.</li>
          <li><strong>Real-Time Availability:</strong> 24/7 accessibility</li>
          <li><strong>Secure & Reliable:</strong> Secure and safe scheduling</li>
        </ul>
      </div>
      <center>
      <footer className="bg-black text-white py-4" style={{opacity:"0.8"}}>
            <div className="container">
              <div className="row">
                <div className="col-md-4">
                  <h5 className="fw-bold mb-3">QUICK LINKS</h5>
                  <ul className="list-unstyled">
                    <li><Link to="/" className="text-decoration-none text-light">Home</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">How To Park</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">About</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">How It Works</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">Start Business</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">Privacy Policy</Link></li>
                    <li><Link to="#" className="text-decoration-none text-light">Terms of Use</Link></li>
                  </ul>
                </div>
                <div className="col-md-4 text-center">
                  <h5 className="fw-bold mb-3">BECOME A PARTNER</h5>
                  <p className="text-light">
                    Convert your empty space into revenue-generating parking spaces with zero investment by partnering with Slotty automated systems.
                  </p>
                </div>
                <div className="col-md-4">
                  <h5 className="fw-bold mb-3">CONTACT US</h5>
                  <p><i className="bi bi-envelope"></i> <a href="/home" className="text-light">Slotty25@Slotty.in</a></p>
                  <p><i className="bi bi-telephone"></i> 8008005072</p>
                  <p><i className="bi bi-geo-alt"></i> Coimbatore</p>
                </div>
      
              </div>
      
              <hr className="bg-light mt-4" />
              <div className="text-center">
                <div className="d-flex justify-content-center gap-3 mb-3">
                  <Link to="#" className="text-light fs-4"><i className="bi bi-facebook"></i></Link>
                  <Link to="#" className="text-light fs-4"><i className="bi bi-twitter"></i></Link>
                  <Link to="#" className="text-light fs-4"><i className="bi bi-linkedin"></i></Link>
                  <Link to="#" className="text-light fs-4"><i className="bi bi-instagram"></i></Link>
                </div>
                <p className="text-light">© 2025 SlottyParking. All rights reserved.</p>
              </div>
            </div>
          </footer> 
      </center>
    </div>
  );
}

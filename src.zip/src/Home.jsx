import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./style.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Slotty from "./Slotty.png";
import frame from "./frame.png";
export default function Home() {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-danger list fixed-top bg-info">
                <div className="container px-4">
                    <Link className="navbar-brand" to="/">
                        <img src={Slotty} className='logo' alt='logo'/>
                    </Link>
                    <button 
                        className="navbar-toggler bg-secondary" 
                        type="button" 
                        onClick={() => setIsOpen(!isOpen)}
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarResponsive">
                        <ul className='navbar-nav ms-auto lit fs-100'>
                            <li className="nav-item"><Link to="/" className='nav-link org '><i className="bi bi-house"></i> Home</Link></li>
                            <li className="nav-item"><Link to="/book" className='nav-link link '><i class="bi bi-p-circle"></i>Book Slot</Link></li>
                            <li className="nav-item"><Link to="/" className='nav-link link '><i class="bi bi-clock-history"></i> My Booking</Link></li>
                            <li className="nav-item"><Link to="/about" className='nav-link link '><i className="bi bi-file-person-fill"></i> About us</Link></li>
                            <li className="nav-item"><Link to="/login" className='nav-link link '><i className="bi bi-box-arrow-right"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className='book-cont'>
                <div className='img'>
                    <img className='img-fluid' src={frame} width='100%' height='100%' alt='frame'/>
                </div>
                <section className="container" >
                    <center>
                        <div className="hero p-3">                       
                            <h1 className='text-white'>Book Your <i>Slot</i> with Ease</h1>
                            <p>Reserve your appointments quickly and conveniently.</p>
                            <Link to="./book" id="link"><button  className="btn book text-white mt-3 bg-danger">Book Now</button></Link>
                        </div> 
                    </center>   
                </section>
            </div>
            <div className="text-center con py-5 px-3 bg-light">
      <h2 className="text-dark fw-bold">Parking <span className="tex">Made</span> Easy</h2>
      <p className="text-muted mt-2 mb-4">
        You can plan and book your parking at thousands of parking spaces across India.
      </p>
      <div className="row justify-content-center">
        <div className="col-md-4 text-center mb-4">
          <div className="display-4 text-primary">📍</div>
          <h3 className="fw-semibold"><span className="tex">SEARCH</span></h3>
          <p className="text-muted">Search for all available parking options closest to your destination.</p>
        </div>
        <div className="col-md-4 text-center mb-4">
          <div className="display-4 text-success">💰</div>
          <h3 className="fw-semibold"><span className="tex">BOOK</span></h3>
          <p className="text-muted">
            Pre-book the perfect parking spot & pay for selected hours using convenient payment options.
          </p>
        </div>
        <div className="col-md-4 text-center mb-4">
          <div className="display-4 text-primary">🅿️</div>
          <h3 className="fw-semibold"><span className="tex">PARK</span></h3>
          <p className="text-muted">
            Navigate to your parking spot, park your vehicle and enjoy a stress-free journey.
          </p>
        </div>
      </div>
    </div>
    <div className="container-fluid bg-dark text-white py-5" style={{
      backgroundSize: "cover",
      backgroundPosition: "center",
      opacity: "0.9"
    }}>
      <div className="container text-start">
        <h2 className="fw-bold">List your Parking Space, Now!</h2>
        <p className="text-light">Give Your Space To SMP & Generate Revenue.</p>
        <button className="btn btn-outline-light mt-3">LET'S START</button>
      </div>
    </div>
            <div className="container py-5" style={{ backgroundColor: "#eef6fd" }}>
      <div className="text-center mb-4">
        <h2>
          <strong className="text-info">Start Business</strong> With SlottyParking
        </h2>
        <p>
          Send us the following Info or Contact us through <strong> Email</strong>
        </p>
      </div>
      
      <form className="container">
        <div className="row g-3">
          <div className="col-md-4 input-group">
            <span className="input-group-text bg-light text-dark border-danger">
            <i class="bi bi-person"></i>
            </span>
            <input type="text" className="form-control border-danger" placeholder="Name" required />
          </div>
          <div className="col-md-4 input-group">
            <span className="input-group-text bg-light border-danger">
            <i class="bi bi-envelope-open"></i>
            </span>
            <input type="email" className="form-control border-danger" placeholder="Email" required />
          </div>
          <div className="col-md-4 input-group">
            <span className="input-group-text bg-light border-danger">
            <i class="bi bi-phone"></i>
            </span>
            <input type="tel" className="form-control border-danger" placeholder="Phone" required />
          </div>
        </div>
        
        <div className="mt-3 input-group">
          <span className="input-group-text bg-light border-danger">
          <i class="bi bi-chat"></i>
          </span>
          <textarea className="form-control border-danger" rows="" placeholder="Your Message Here" required></textarea>
        </div>
        
        <div className="text-center mt-4">
          <button type="submit" className="btn btn-info px-5">SEND REQUEST</button>
        </div>
      </form>
    </div>
    <footer className="bg-black text-white py-4" style={{opacity:"0.8"}}>
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h5 className="fw-bold mb-3">QUICK LINKS</h5>
            <ul className="list-unstyled">
              <li><Link to="/" className="text-decoration-none text-light">Home</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">How To Park</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">About</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">How It Works</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">Start Business</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">Privacy Policy</Link></li>
              <li><Link to="#" className="text-decoration-none text-light">Terms of Use</Link></li>
            </ul>
          </div>
          <div className="col-md-4 text-center">
            <h5 className="fw-bold mb-3">BECOME A PARTNER</h5>
            <p className="text-light">
              Convert your empty space into revenue-generating parking spaces with zero investment by partnering with InstaParking automated cashless systems.
            </p>
          </div>
          <div className="col-md-4">
            <h5 className="fw-bold mb-3">CONTACT US</h5>
            <p><i className="bi bi-envelope"></i> <a href="/home" className="text-light">Slotty25@Slotty.in</a></p>
            <p><i className="bi bi-telephone"></i> 8008005072</p>
            <p><i className="bi bi-geo-alt"></i> Coimbatore</p>
          </div>

        </div>

        <hr className="bg-light mt-4" />
        <div className="text-center">
          <div className="d-flex justify-content-center gap-3 mb-3">
            <Link to="#" className="text-light fs-4"><i className="bi bi-facebook"></i></Link>
            <Link to="#" className="text-light fs-4"><i className="bi bi-twitter"></i></Link>
            <Link to="#" className="text-light fs-4"><i className="bi bi-linkedin"></i></Link>
            <Link to="#" className="text-light fs-4"><i className="bi bi-instagram"></i></Link>
          </div>
          <p className="text-light">© 2025 SlottyParking. All rights reserved.</p>
        </div>
      </div>
    </footer>      
    </div>
    );
}
